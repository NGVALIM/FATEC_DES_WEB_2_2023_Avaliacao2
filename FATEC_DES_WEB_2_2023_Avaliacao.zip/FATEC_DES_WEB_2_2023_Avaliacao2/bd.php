
<?php

$con = mysqli_connect("localhost","root","","candidato");

if(!$con){
    die('Connection Failed'. mysqli_connect_error());
}

?>
